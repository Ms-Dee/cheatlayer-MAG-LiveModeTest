# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 9.x   | :white_check_mark: |
| 8.x   | :white_check_mark: till 2025 April 30 |
| <= 7.x   | :x:                |

## Reporting a Vulnerability

Send and email to security@pnpm.io
