# @pnpm/catalogs.resolver

> Dereferences `catalog:` protocol specifiers into usable specifiers.
