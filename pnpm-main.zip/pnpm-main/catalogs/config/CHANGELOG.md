# @pnpm/catalogs.config

## 0.1.0

Initial release
