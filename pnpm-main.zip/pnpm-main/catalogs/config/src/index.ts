export { getCatalogsFromWorkspaceManifest } from './getCatalogsFromWorkspaceManifest'
