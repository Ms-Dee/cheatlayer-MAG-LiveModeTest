# @pnpm/catalogs.config

> Create a normalized catalogs config from `pnpm-workspace.yaml` contents.
