'use strict'

module.exports = {
  extends: ['@commitlint/config-conventional']
}
