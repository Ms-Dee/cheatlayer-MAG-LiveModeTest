# @pnpm-private/typings

## 0.1.3

### Patch Changes

- 9fb45d0fc: `pnpm publish` should pack "main" file or "bin" files defined in "publishConfig" [#4195](https://github.com/pnpm/pnpm/issues/4195).

## 0.1.2

### Patch Changes

- 4246f41be: Add package @pnpm/deps.graph-sequencer for better topological sort [#7168](https://github.com/pnpm/pnpm/pull/7168).

## 0.1.1

### Patch Changes

- 42c1ea1c0: Update validate-npm-package-name to v4.

## 0.1.0

### Minor Changes

- 1442f8786: Warn about cyclic dependencies on install
