# @pnpm/get-release-text

## 0.0.1

### Patch Changes

- 238a165a5: dependencies maintenance
