module.exports = require('../../jest.config')
