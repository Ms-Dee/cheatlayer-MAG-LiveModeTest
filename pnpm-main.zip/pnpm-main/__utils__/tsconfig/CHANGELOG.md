# @pnpm/tsconfig

## 2.0.0

### Major Changes

- 542014839: Node.js 12 is not supported.
