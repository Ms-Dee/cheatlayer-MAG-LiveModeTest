module.exports = require('./eslint.json')
