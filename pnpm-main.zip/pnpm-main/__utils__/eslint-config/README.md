# @pnpm/eslint-config

> pnpm's ESLint configuration

## Installation

```
pnpm add -D @pnpm/eslint-config tslint
```

## Usage

Create the following `eslint.json` file:

```json
{
  "extends": "@pnpm/eslint-config"
}
```

## License

MIT
