# @pnpm/command

## 5.0.2

### Patch Changes

- 9b5b869: update @pnpm/tabtab to v0.5.4, enabling zsh autocomplete lazy loading [#8236](https://github.com/pnpm/pnpm/pull/8236).

## 5.0.1

### Patch Changes

- 37538f5: Update the `@pnpm/tabtab` to v0.5.3 which include a fix for shell completion on MinGW-w64 environment.

## 5.0.0

### Major Changes

- 43cdd87: Node.js v16 support dropped. Use at least Node.js v18.12.

## 4.0.0

### Major Changes

- eceaa8b8b: Node.js 14 support dropped.

## 3.0.0

### Major Changes

- 542014839: Node.js 12 is not supported.

## 2.0.0

### Major Changes

- 97b986fbc: Node.js 10 support is dropped. At least Node.js 12.17 is required for the package to work.
