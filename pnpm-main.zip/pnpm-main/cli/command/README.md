# @pnpm/command

> Types and utils for pnpm commands

[![npm version](https://img.shields.io/npm/v/@pnpm/command.svg)](https://www.npmjs.com/package/@pnpm/command)

## Installation

```sh
pnpm add @pnpm/command
```

## License

MIT
