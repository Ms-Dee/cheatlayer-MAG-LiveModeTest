# @pnpm/common-cli-options-help

> Help for some common CLI options

[![npm version](https://img.shields.io/npm/v/@pnpm/common-cli-options-help.svg)](https://www.npmjs.com/package/@pnpm/common-cli-options-help)

## Installation

```sh
pnpm add @pnpm/common-cli-options-help
```

## License

MIT
