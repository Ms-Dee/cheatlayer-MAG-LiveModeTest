# @pnpm/common-cli-options-help

## 2.0.0

### Major Changes

- 43cdd87: Node.js v16 support dropped. Use at least Node.js v18.12.

## 1.1.0

### Minor Changes

- 4e71066dd: Use `--fail-if-no-match` if you want the CLI fail if no packages were matched by the command [#7403](https://github.com/pnpm/pnpm/issues/7403).

## 1.0.0

### Major Changes

- eceaa8b8b: Node.js 14 support dropped.

## 0.9.0

### Minor Changes

- 542014839: Node.js 12 is not supported.

## 0.8.0

### Minor Changes

- 927c4a089: A new option `--aggregate-output` for `append-only` reporter is added. It aggregates lifecycle logs output for each command that is run in parallel, and only prints command logs when command is finished.

  Related discussion: [#4070](https://github.com/pnpm/pnpm/discussions/4070).

## 0.7.1

### Patch Changes

- 1efaaf706: `OUTPUT_OPTIONS` added.

## 0.7.0

### Minor Changes

- fe5688dc0: Add option 'changed-files-ignore-pattern' to ignore changed files by glob patterns when filtering for changed projects since the specified commit/branch.

## 0.6.0

### Minor Changes

- c2a71e4fd: New CLI option added: `use-stderr`. When set, all the output is written to stderr.

## 0.5.0

### Minor Changes

- dfdf669e6: Add new cli arg --filter-prod. --filter-prod acts the same as --filter, but it omits devDependencies when building dependencies

## 0.4.0

### Minor Changes

- 97b986fbc: Node.js 10 support is dropped. At least Node.js 12.17 is required for the package to work.

## 0.3.1

### Patch Changes

- a5e9d903c: Update help for filters. Some of the filtering patterns should be escaped in zsh.

## 0.3.0

### Minor Changes

- 1ec47db33: New CLI option added: `--test-pattern`.

## 0.2.0

### Minor Changes

- 092f8dd83: New universal option added: -w, --workspace-root.

## 0.1.6

### Minor Changes

- ffddf34a8: Add `--stream` option description to the `UNIVERSAL_OPTIONS` array.
