// In terminals, always Unix line endings are used
// even on Windows
export const EOL = '\n'
