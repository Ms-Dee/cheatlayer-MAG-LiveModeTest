# @pnpm/parse-cli-args

> Parses the CLI args passed to pnpm

[![npm version](https://img.shields.io/npm/v/@pnpm/parse-cli-args.svg)](https://www.npmjs.com/package/@pnpm/parse-cli-args)

## Installation

```sh
pnpm add @pnpm/parse-cli-args
```

## License

MIT
