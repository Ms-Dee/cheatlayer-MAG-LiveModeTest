# @pnpm/dedupe.issues-renderer

> Visualizes "pnpm dedupe --check" issues

## Installation

```
pnpm add @pnpm/dedupe.issues-renderer
```

## License

[MIT](LICENSE)
