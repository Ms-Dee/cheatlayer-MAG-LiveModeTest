# @pnpm/dedupe.issues-renderer

## 2.0.0

### Major Changes

- 43cdd87: Node.js v16 support dropped. Use at least Node.js v18.12.

### Patch Changes

- Updated dependencies [43cdd87]
  - @pnpm/dedupe.types@2.0.0

## 1.0.0

### Major Changes

- 6850bb135: Initial release.

### Patch Changes

- Updated dependencies [6850bb135]
  - @pnpm/dedupe.types@1.0.0
