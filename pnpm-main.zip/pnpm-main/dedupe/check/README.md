# @pnpm/dedupe.issues-renderer

> Logic for "pnpm dedupe --check"

## Installation

```
pnpm add @pnpm/dedupe.check
```

## License

[MIT](LICENSE)
