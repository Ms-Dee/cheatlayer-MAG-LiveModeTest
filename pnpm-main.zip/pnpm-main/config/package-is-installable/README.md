# @pnpm/package-is-installable

> Checks if a package is installable on the current system

## Install

```
pnpm install @pnpm/package-is-installable
```

## License

MIT
