# @pnpm/pick-registry-for-package

> Picks the right registry for the package from a registries config

## Installation

```
pnpm add @pnpm/pick-registry-for-package
```

## License

[MIT](LICENSE)
