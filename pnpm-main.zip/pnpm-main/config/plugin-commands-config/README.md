# @pnpm/plugin-commands-config

> Commands for reading and writing settings to/from config files

[![npm version](https://img.shields.io/npm/v/@pnpm/plugin-commands-config.svg)](https://www.npmjs.com/package/@pnpm/plugin-commands-config)

## Installation

```sh
pnpm add @pnpm/plugin-commands-config
```

## License

MIT
