module.exports = require('../../jest-with-registry.config.js')
