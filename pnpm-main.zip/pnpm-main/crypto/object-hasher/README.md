# @pnpm/crypto.object-hasher

> Generate hashes from objects

## Installation

```sh
pnpm add @pnpm/crypto.object-hasher
```

## License

MIT
