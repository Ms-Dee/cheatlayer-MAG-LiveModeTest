# @pnpm/crypto.object-hasher

## 2.0.0

### Major Changes

- d636eed: fix(object-hasher): switch to object-hash to fix hashing of large objects

## 1.0.0

### Major Changes

- 0c383327e: Initial release.
